#ifndef rush02lib
#define rush02lib

int	ft_atoi(char	**argv);

#endif
